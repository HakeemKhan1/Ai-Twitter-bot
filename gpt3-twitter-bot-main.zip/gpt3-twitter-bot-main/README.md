# AI-powered Twitter Bot

Build a Twitter Bot with OpenAI to tweet awesome content on #techtwitter. 

Watch the [Twitter Bot Tutorial](https://youtu.be/V7LEihbOv3Y) on YouTube. 
